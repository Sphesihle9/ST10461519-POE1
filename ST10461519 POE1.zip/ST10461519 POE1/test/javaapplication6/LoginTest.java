/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package javaapplication6;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class LoginTest {
    
    public LoginTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

      /**
     * Test of checkUserName method, of class Login.
     */
    Login login = new Login();
    
    @Test
    public void testCheckUserName_ValidUserName() {
        assertTrue(login.checkUserName("na_me"));
    }
    
    @Test
    public void testCheckUserName_InvalidUserName(){
        assertFalse(login.checkUserName("Name"));
    }

    /**
     * Test of checkPasswordComplexity method, of class Login.
     */
    @Test
    public void testCheckPasswordComplexity_ValidPassword() {
        assertTrue(login.checkPasswordComplexity("pa$sW0rd"));
    }

    @Test
    public void testCheckPasswordComplexity_InvalidPassword() {
        assertTrue(login.checkPasswordComplexity("password"));
    }
    /**
     * Test of registeUser method, of class Login.
     */
    @Test
    public void testRegisteUser() {
        String result = login.registeUser("na_me", "pa$sW0rd");
        assertEquals("UserName successfully captured /n Password is successfully capture ",result);
    }

    @Test
    public void testRegisteUser_InvalidUseNameAndPass() {
        String result = login.registeUser("Name", "password");
        assertEquals("UserName is not correctly formated, please ensure thta your userName contains 5 characters including an underscore /n Password is not correctly formated, please ensure that password contains a capital letter, special character, a number and it must be 8 characters long ",result);
    }
    /**
     * Test of LoginUser method, of class Login.
     */
    @Test
    public void testLoginUser_Successfull() {
       login.registeUser("na_me","pa$sW0rd");
       boolean loginResult = login.LoginUser(true, true);
       assertTrue(loginResult);
    }

     @Test
    public void testLoginUser_Successfull_Faliure() {
       login.registeUser("Name","password");
       boolean loginResult = login.LoginUser(false, false);
       assertFalse(loginResult);
    }
    /**
     * Test of returnLoginStatus method, of class Login.
     */
    @Test
    public void testReturnLoginStatus_Successful() {
     String result = login.returnLoginStatus(true, "firstName", "lastName");
     assertEquals ("Welcome firstName lastName, it's great to see you!",result);
    }
    
    public void testReturnLoginStatus_Failure() {
     String result = login.returnLoginStatus(false, "firstName", "lastName");
     assertEquals (" ",result);
    }
}
     