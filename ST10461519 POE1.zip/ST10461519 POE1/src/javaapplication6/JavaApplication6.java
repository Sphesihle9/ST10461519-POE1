/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication6;

import java.util.Scanner;

/**
 *
 * @author RC_Student_lab
 */
public class JavaApplication6 {
    //declaring variables with access specifiers
 
    private static String firstName;
    private static String lastName;
    private static String userName;
    private static String password;
    
    //set and get the first name
    public static void setFirstName(String name){               
        firstName = name;
    }
    public static String getFirstName(){
        return firstName;
    }
    //set and get user name
    public static void setUserName(String useName){               
        userName = useName;
    }
    public static String getUserName(){
        return userName;
    }
    //set and get the password
    public static void setPassword(String pass){
        password = pass;
    }
    public static String getPassword(){
        return password;
    }
    
    //set and get the user's surname
    public static void setlastName(String lname){
        lastName = lname;
    }
    public static String getlastName(){
        return lastName;
    }

    //method registering user, using the scanner to get their information
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Login logObj = new Login();
        //getting user details
        System.out.println("**Registration**");
        System.out.println("");
        System.out.println("Enter your first name"); 
        setFirstName (input.nextLine()); 
        System.out.println("Enter your last name");
        setlastName (input.nextLine());
        System.out.println("Enter your user name, Note: User name must be less than 5 characters long including an underscore");
        setUserName (input.nextLine());
        
        //calling methods
        logObj.checkUserName(getUserName());
        
        System.out.println("Enter your password");   
        setPassword (input.nextLine());

        
        System.out.println(logObj.registeUser(getUserName(), getPassword()));
        boolean regStatus = logObj.LoginUser(logObj.checkUserName(getUserName()),logObj.checkPasswordComplexity(getPassword()));
        
        System.out.println(logObj.returnLoginStatus(regStatus, getFirstName(),getlastName()));
    }
}

