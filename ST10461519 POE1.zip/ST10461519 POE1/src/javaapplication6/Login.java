/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication6;

import java.util.Scanner;

/**
 *
 * @author RC_Student_lab
 */
public class Login {
    JavaApplication6 javaObject = new JavaApplication6(); 
    String passMessage = "Password is not correctly formated, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character";
    String nameMessage = "User name is not correctly formated, please ensure that your user name contains an underscore and is no more than" + "5 characters in length";
    
    //method checking the strength of the user name for an underscore and making sure it is 5 characters
    public boolean checkUserName(String userName){
        if (userName.length()<= 5 && userName.contains("_")){
            return true;
        }
        return false;
    }
    
    public boolean checkPasswordComplexity (String password){
    //declaring variables
        boolean passwordOk = false;
        boolean hasNumber = false;
        boolean hasCap = false;
        boolean hasChar = false;
        char current; // current evaluates characters individually
        
    //checking password complexity fot a capital letter, number and special character
        if (password.length() >= 8){
            for (int i = 0; i < password.length();i++ ){
                current = password.charAt(i);
                if (Character.isUpperCase(current)){
                    hasCap = true;
                }
                if (Character.isDigit(current)){
                    hasNumber = true;
                }
                if (!Character.isLetterOrDigit(current)){// if it is not a letter or digit 
                    hasChar = true;
        }
                if (hasNumber&& hasCap&& hasChar){
                    passwordOk = true;
                }
                
        }
        }
        return passwordOk;
    }
    //method used to capture users registration information
    public String registeUser(String name,String password){
                if (checkPasswordComplexity(password)){
                    passMessage = "Password is successfully captured";
                }
                if (checkUserName(name )){
                    nameMessage = "UserName successfully captured";
                }
                return (passMessage + "\n" + nameMessage);
                }
    // method used for users to login, using scanner to get users unformation      
    public boolean LoginUser (boolean checkName, boolean checkPassword){
        boolean logged = false;
        if (checkName && checkPassword){  
            Scanner input = new Scanner(System. in);
            
            System.out.println("***LOGIN***");
            System.out.println("");
            System.out.println("Please enter the username you provided earlier");
            String userName = input.nextLine();
            System.out.println("Please enter the password you provided earlier");
            String password = input.nextLine();
            
            if ( password.equals(javaObject.getPassword()) && userName.equals(javaObject.getUserName())){
                logged = true;
            }
        }
        return logged;
                }
    // method that returns the users login status
    public String returnLoginStatus(boolean regStatus, String name, String lastName){
        String message = "";
        
           if (regStatus){
               message = "Welcome " + name + " " + lastName +"," + " it's great to see you!";
           }
        return message;
    }
}
 